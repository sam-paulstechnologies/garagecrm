<?php

namespace App\Models\Tenant;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Opportunity extends Model
{
    protected $fillable = [
    'client_id',
    'lead_id',
    'company_id',
    'title',
    'service_type',
    'stage',
    'value',
    'expected_close_date',
    'notes',
    'source',
    'assigned_to',
    'priority',
    'is_converted',
    'close_reason',
    'next_follow_up',
    'expected_duration',
    'score',
    'vehicle_id',
    'vehicle_make_id',     // ✅ Add this
    'vehicle_model_id',    // ✅ Add this
    'other_make',          // ✅ Add this
    'other_model',         // ✅ Add this
];


    // 🔗 Relationships
    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function lead()
    {
        return $this->belongsTo(Lead::class);
    }

    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    // 📌 Accessors & Mutators
    public function getServiceTypeArrayAttribute()
    {
        return explode(',', $this->service_type ?? '');
    }

    public function setServiceTypeArrayAttribute($value)
    {
        $this->attributes['service_type'] = is_array($value) ? implode(',', $value) : $value;
    }

    // 🔍 Scopes
    public function scopeForCompany($query, $companyId)
    {
        return $query->where('company_id', $companyId);
    }

    // 🚗 Optional: fallback to lead vehicle if set
    public function getDefaultVehicleAttribute()
    {
        return $this->lead?->vehicle ?? null;
    }

    public function vehicleMake()
{
    return $this->belongsTo(VehicleMake::class, 'vehicle_make_id');
}

public function vehicleModel()
{
    return $this->belongsTo(VehicleModel::class, 'vehicle_model_id');
}

}
