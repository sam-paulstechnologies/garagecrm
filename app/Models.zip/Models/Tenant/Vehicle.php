<?php

namespace App\Models\Tenant;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Vehicle extends Model
{
    use HasFactory;

    protected $fillable = [
        'client_id',
        'vehicle_model_id',
        'trim',
        'plate_number',
        'year',
        'color',
        'registration_expiry_date',
        'insurance_expiry_date',
    ];

    // Relationships
    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function model()
    {
        return $this->belongsTo(VehicleModel::class, 'vehicle_model_id');
    }

    public function make()
    {
        return $this->model ? $this->model->make : null;
    }

    public function opportunities()
    {
        return $this->hasMany(Opportunity::class);
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    // Accessors
    public function getMakeNameAttribute()
    {
        return $this->make()?->name;
    }

    public function getModelNameAttribute()
    {
        return $this->model?->name;
    }

    public function getDisplayNameAttribute()
    {
        return trim("{$this->make_name} {$this->model_name} {$this->trim}");
    }
}
