<?php

namespace App\Models\Tenant;

use Illuminate\Database\Eloquent\Model;

class VehicleMake extends Model
{
    protected $fillable = ['name'];

    public function models()
{
    return $this->hasMany(VehicleModel::class, 'make_id');
}

}
