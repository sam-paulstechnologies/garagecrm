<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Template extends Model
{
    protected $fillable = [
        'company_id',
        'name',
        'category',
        'type',
        'content',
        'is_global',
    ];

    public function company()
    {
        return $this->belongsTo(\App\Models\Company::class);
    }

    public function scopeVisibleToCompany($query, $companyId)
    {
        return $query->where(function ($q) use ($companyId) {
            $q->where('company_id', $companyId)
              ->orWhere('is_global', true);
        });
    }
}
