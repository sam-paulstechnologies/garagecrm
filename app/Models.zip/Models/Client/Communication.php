<?php

namespace App\Models\Tenant;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Communication extends Model
{
    use HasFactory;

    protected $fillable = [
        'client_id',
        'communication_type', // renamed for clarity
        'content',
        'communication_date',
        'follow_up_required',
        'company_id',
    ];

    protected $casts = [
        'communication_date' => 'datetime',
        'follow_up_required' => 'boolean',
    ];

    public function client()
    {
        return $this->belongsTo(\App\Models\Tenant\Client::class);
    }

    public function company()
    {
        return $this->belongsTo(\App\Models\System\Company::class);
    }
}
