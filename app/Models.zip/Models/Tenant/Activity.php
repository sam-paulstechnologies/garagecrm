<?php

namespace App\Models\Tenant;

use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    protected $fillable = [
        'client_id',
        'description',
        'performed_by',
        'performed_at',
    ];

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'performed_by');
    }
}
