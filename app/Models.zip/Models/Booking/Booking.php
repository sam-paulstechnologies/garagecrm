<?php

namespace App\Models\Tenant;

use App\Models\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Tenant\Client;
use App\Models\Tenant\Opportunity;
use App\Models\User;
use App\Models\Tenant\Vehicle;
use App\Models\Tenant\Job;
use App\Models\Tenant\VehicleMake;
use App\Models\Tenant\VehicleModel;

class Booking extends Model
{
    use HasFactory, BelongsToCompany;

    protected $fillable = [
        'client_id',
        'opportunity_id',
        'vehicle_id',
        'vehicle_make_id',
        'vehicle_model_id',
        'other_make',
        'other_model',
        'name',
        'service_type',
        'date',
        'slot',
        'assigned_to',
        'pickup_required',
        'pickup_address',
        'pickup_contact_number',
        'status',
        'notes',
        'company_id',
        'source',
        'priority',
        'expected_duration',
        'expected_close_date',
        'is_archived',
    ];

    protected $casts = [
        'pickup_required' => 'boolean',
        'date' => 'date',
        'expected_close_date' => 'date',
    ];

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function opportunity()
    {
        return $this->belongsTo(Opportunity::class);
    }

    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function vehicleData()
    {
        return $this->belongsTo(Vehicle::class, 'vehicle_id');
    }

    public function job()
    {
        return $this->hasOne(Job::class);
    }

    public function make()
    {
        return $this->belongsTo(VehicleMake::class, 'vehicle_make_id');
    }

    public function model()
    {
        return $this->belongsTo(VehicleModel::class, 'vehicle_model_id');
    }
}
