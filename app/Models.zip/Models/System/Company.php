<?php

namespace App\Models\System;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;
use App\Models\System\Plan;

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'email', 'phone', 'address', 'plan_id', 'trial_ends_at',
    ];

    protected $casts = [
        'trial_ends_at' => 'datetime',
    ];

    // Relationships
    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class);
    }

    // Check if company is still under trial
    public function isTrialActive()
    {
        return $this->trial_ends_at && now()->lt($this->trial_ends_at);
    }

    // Always return correct plan:
    // - If trial is active, return actual assigned plan (Enterprise)
    // - Else return Freemium (Plan ID = 1)
    public function getActivePlanAttribute()
    {
        if ($this->isTrialActive() && $this->plan) {
            return $this->plan;
        }

        return Plan::find(1); // Freemium fallback
    }
}
