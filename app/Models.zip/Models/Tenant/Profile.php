<?php

namespace App\Models\Tenant;

use App\Models\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    use HasFactory, BelongsToCompany;

    protected $fillable = [
        'user_id',
        'phone',
        'address',
        'profile_picture',
        'company_id',
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
